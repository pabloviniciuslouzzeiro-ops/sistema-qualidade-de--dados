"""
Sistema de Gestao para Salao - Revitalizar
Squad G3 | MVP funcional (Vibe Coding - Streamlit)

Requisitos atendidos:
  RF01 Agendamento de servicos e controle de atendimento
  RF02 Gestao de entrada e saida de produtos (estoque, com baixa automatica)
  RF03 Gestao de entrada e saida de valores (financeiro)
  RF04 Apresenta localizacao
  RNF01 Troca de dados via JSON | RNF02 Confirmacao pelo atendente | RNF03 Responsivo

Banco de dados: dados.json (escrita atomica, sem dependencia externa).
UX/UI: tokens de design da referencia divasbyregiane.vercel.app.
"""

import json
import os
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

PASTA = Path(__file__).parent
DB = PASTA / "dados.json"
SCHEMA = PASTA / "schema_dados.json"

SERVICOS = {
    "Progressiva sem formol": 180.00,
    "Escova / Hidratacao": 60.00,
    "Manicure": 35.00,
    "Pedicure": 40.00,
    "Higienizacao de pes e unhas": 50.00,
    "Terapia por ventosa": 90.00,
}

# Insumos consumidos por atendimento -> baixa automatica no estoque ao concluir (RF01 -> RF02)
INSUMOS = {
    "Progressiva sem formol": [("Progressiva sem formol (1L)", 1), ("Shampoo profissional (1L)", 1)],
    "Escova / Hidratacao": [("Shampoo profissional (1L)", 1)],
    "Manicure": [("Esmalte (unidade)", 1), ("Algodao / acetona (kit)", 1)],
    "Pedicure": [("Esmalte (unidade)", 1), ("Algodao / acetona (kit)", 1)],
    "Higienizacao de pes e unhas": [("Algodao / acetona (kit)", 1)],
    "Terapia por ventosa": [("Ventosa de silicone (kit)", 1)],
}

PROFISSIONAIS = ["Safira", "Edson", "Matheus", "Pyetro"]
STATUS = ["Pendente", "Confirmado", "Concluido", "Cancelado"]
DIAS_RELAMPAGO = (0, 1)  # segunda e terca: baixo movimento -> promocao relampago
DESCONTO_RELAMPAGO = 0.15
DIAS_INATIVO = 30  # cliente sem voltar depois disso entra na lista de reativacao

ENDERECO = {
    "logradouro": "Av. Brasil, 1420 - Centro",
    "cidade": "Sao Paulo - SP",
    "cep": "01000-000",
    "telefone": "(11) 98888-1234",
    "lat": -23.5505,
    "lon": -46.6333,
    "horarios": {"Segunda a sexta": "09h - 19h", "Sabado": "09h - 17h", "Domingo": "Fechado"},
}

VAZIO = {
    "_meta": {"versao": 2, "cliente": "Revitalizar", "squad": "G3"},
    "agendamentos": [],
    "estoque": [
        {"produto": "Progressiva sem formol (1L)", "saldo": 6, "minimo": 3, "custo": 120.0},
        {"produto": "Shampoo profissional (1L)", "saldo": 10, "minimo": 4, "custo": 45.0},
        {"produto": "Esmalte (unidade)", "saldo": 24, "minimo": 10, "custo": 6.5},
        {"produto": "Algodao / acetona (kit)", "saldo": 12, "minimo": 5, "custo": 18.0},
        {"produto": "Ventosa de silicone (kit)", "saldo": 2, "minimo": 3, "custo": 80.0},
    ],
    "movimentos_estoque": [],
    "financeiro": [],
}


# ---------------------------------------------------------------- banco (JSON)
def carregar():
    """Le o banco do disco a cada rerun - sem cache, evita estado velho entre abas."""
    if not DB.exists():
        return json.loads(json.dumps(VAZIO))
    dados = json.loads(DB.read_text(encoding="utf-8"))
    for chave, vazio_ in VAZIO.items():  # migra bases antigas sem quebrar
        dados.setdefault(chave, json.loads(json.dumps(vazio_)))
    for item in dados["estoque"]:
        item.setdefault("minimo", 0)
        item.setdefault("custo", 0.0)
    return dados


def salvar(dados):
    """Escrita atomica: grava no .tmp e troca, para nao corromper o JSON."""
    tmp = DB.with_suffix(".tmp")
    tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, DB)


def proximo_id(lista, prefixo):
    usados = [int(x["id"][len(prefixo):]) for x in lista if str(x.get("id", "")).startswith(prefixo)]
    return f"{prefixo}{max(usados, default=0) + 1:04d}"


# ------------------------------------------------------------- regra de negocio
def brl(v):
    """1234.5 -> 'R$ 1.234,50' (padrao brasileiro)."""
    return f"R$ {v:,.2f}".translate(str.maketrans({",": ".", ".": ","}))


def classificar(servico, data_ag, recorrente, orcamento_mensal):
    """Score 0-100 do agendamento -> saida no formato do schema do briefing."""
    valor = SERVICOS[servico]
    score = 40
    score += min(int(valor / 180 * 25), 25)             # ticket do servico
    score += 15 if recorrente else 0                     # fidelidade
    score += min(int(orcamento_mensal / 500 * 15), 15)   # potencial mensal
    relampago = data_ag.weekday() in DIAS_RELAMPAGO
    score += 5 if relampago else 0                       # ocupa dia ocioso
    score = max(0, min(score, 100))

    if score >= 80:
        classe, passo = "LEAD_QUALIFICADO_ALTO_VALOR", "Confirmar por WhatsApp hoje e oferecer pacote fidelidade."
    elif score >= 60:
        classe, passo = "LEAD_QUALIFICADO_MEDIO", "Confirmar por WhatsApp em ate 24h e lembrar 1 dia antes."
    else:
        classe, passo = "LEAD_BAIXA_PRIORIDADE", "Enviar lembrete automatico e oferecer promocao relampago."

    desconto = round(valor * DESCONTO_RELAMPAGO, 2) if relampago else 0.0
    return {
        "resultado_processado": classe,
        "pontuacao_score": score,
        "recomendacao_proximo_passo": passo,
        "valor_bruto": valor,
        "desconto_relampago": desconto,
        "valor_final": round(valor - desconto, 2),
    }


def lancar_financeiro(dados, tipo, categoria, descricao, valor, data_mov, origem=""):
    dados["financeiro"].append({
        "id": proximo_id(dados["financeiro"], "FIN"),
        "data": str(data_mov), "tipo": tipo, "categoria": categoria,
        "descricao": descricao, "valor": round(float(valor), 2), "origem": origem,
    })


def mover_estoque(dados, produto, tipo, quantidade, motivo, origem=""):
    """Aplica a movimentacao e devolve o item (saldo negativo = furo de estoque)."""
    item = next((p for p in dados["estoque"] if p["produto"] == produto), None)
    if item is None:  # insumo citado em INSUMOS mas nunca cadastrado
        item = {"produto": produto, "saldo": 0, "minimo": 0, "custo": 0.0}
        dados["estoque"].append(item)
    item["saldo"] += quantidade if tipo == "entrada" else -quantidade
    dados["movimentos_estoque"].append({
        "data": str(date.today()), "produto": produto, "tipo": tipo,
        "quantidade": int(quantidade), "motivo": motivo,
        "saldo_apos": item["saldo"], "origem": origem,
    })
    return item


def concluir_atendimento(dados, ag):
    """Conclui o agendamento: receita no financeiro + baixa dos insumos no estoque."""
    ag["status"] = "Concluido"
    ag["concluido_em"] = datetime.now().isoformat(timespec="seconds")
    lancar_financeiro(dados, "entrada", "Servico", f"{ag['servico']} - {ag['cliente']}",
                      ag["saida"]["valor_final"], ag["data"], origem=ag["id"])
    avisos, baixados = [], []
    for produto, qtd in INSUMOS.get(ag["servico"], []):
        item = mover_estoque(dados, produto, "saida", qtd,
                             f"Atendimento {ag['id']} - {ag['cliente']}", origem=ag["id"])
        baixados.append(f"{qtd}x {produto} (saldo {item['saldo']})")
        if item["saldo"] < 0:
            avisos.append(f"{produto}: saldo negativo ({item['saldo']}) - registre a reposicao.")
        elif item["saldo"] <= item["minimo"]:
            avisos.append(f"{produto}: atingiu o estoque minimo ({item['saldo']}/{item['minimo']}).")
    ag["insumos_baixados"] = baixados
    return baixados, avisos


def saldo_financeiro(dados):
    ent = sum(m["valor"] for m in dados["financeiro"] if m["tipo"] == "entrada")
    sai = sum(m["valor"] for m in dados["financeiro"] if m["tipo"] == "saida")
    return ent, sai, ent - sai


def resumo_clientes(dados):
    """Historico por cliente, derivado dos agendamentos (sem tabela separada)."""
    por_cliente = {}
    for a in dados["agendamentos"]:
        if a["status"] == "Cancelado":
            continue
        c = por_cliente.setdefault(a["cliente"], {
            "cliente": a["cliente"], "telefone": a["telefone"], "visitas": 0,
            "total_gasto": 0.0, "ultima_visita": None, "proximo": None,
            "servicos": set(), "score": 0,
        })
        c["telefone"] = a["telefone"] or c["telefone"]
        c["servicos"].add(a["servico"])
        c["score"] = max(c["score"], a["saida"]["pontuacao_score"])
        if a["status"] == "Concluido":
            c["visitas"] += 1
            c["total_gasto"] += a["saida"]["valor_final"]
            if c["ultima_visita"] is None or a["data"] > c["ultima_visita"]:
                c["ultima_visita"] = a["data"]
        elif a["data"] >= str(date.today()):
            if c["proximo"] is None or a["data"] < c["proximo"]:
                c["proximo"] = a["data"]
    for c in por_cliente.values():
        c["servicos"] = ", ".join(sorted(c["servicos"]))
        c["dias_sem_voltar"] = (
            (date.today() - date.fromisoformat(c["ultima_visita"])).days if c["ultima_visita"] else None
        )
    return sorted(por_cliente.values(), key=lambda c: c["total_gasto"], reverse=True)


# ------------------------------------------------------------------------- UI
st.set_page_config(page_title="Revitalizar | Gestao de Salao", page_icon="*", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Noto+Serif:wght@600;700&display=swap');
:root{
  --primary:#DD2C67; --secondary:#E4819A; --accent:#FBDFE8; --accent-fg:#AF1C4D;
  --card:#FDF7F9; --muted:#F4EBEE; --muted-fg:#766068; --fg:#1F1419;
  --border:#EAD7DD; --side:#FCF3F6; --side-active:#F3DDE4; --radius:12px;
}
html, body, [class*="st-"], button, input, textarea, select{ font-family:'Manrope', system-ui, sans-serif; }
[data-testid="stIconMaterial"]{ font-family:'Material Symbols Rounded' !important; }
.stApp{ background:linear-gradient(to bottom right,#FFFFFF,rgba(253,242,248,.5),rgba(252,231,243,.3)); }
.block-container{ padding-top:1.6rem; max-width:1240px; }
h1,h2,h3{ font-family:'Noto Serif', Georgia, serif; color:var(--fg); letter-spacing:-.01em; }
[data-testid="stHeader"]{ background:transparent; }
hr{ border-color:var(--border); }

/* ---- cabecalho ---- */
.hero{ display:flex; align-items:center; gap:16px; margin-bottom:10px; }
.hero-logo{ width:54px; height:54px; border-radius:18px; flex:none;
  background:linear-gradient(to bottom right,var(--primary),var(--secondary));
  box-shadow:0 8px 24px rgba(221,44,103,.3); color:#fff; font-family:'Noto Serif',serif;
  font-size:26px; font-weight:700; display:flex; align-items:center; justify-content:center; }
.hero-tit{ font-family:'Noto Serif',serif; font-size:2rem; font-weight:700; color:var(--fg); line-height:1.15; }
.hero-sub{ font-size:.72rem; letter-spacing:.22em; text-transform:uppercase; color:var(--primary); font-weight:700; }

/* ---- barra lateral ---- */
section[data-testid="stSidebar"]{ background:var(--side); border-right:1px solid var(--border); }
section[data-testid="stSidebar"] *{ color:var(--fg); }
section[data-testid="stSidebar"] div[role="radiogroup"]{ display:flex; flex-direction:column;
  align-items:stretch; gap:4px; }
section[data-testid="stSidebar"] div[role="radiogroup"] label{
  display:flex; align-items:center; width:100%; padding:9px 14px; border-radius:var(--radius);
  border:1px solid transparent; font-weight:600; font-size:.93rem; cursor:pointer; transition:all .15s; }
section[data-testid="stSidebar"] div[role="radiogroup"] label:not([data-selected="true"]):hover{ background:var(--side-active); }
section[data-testid="stSidebar"] label[data-testid="stRadioOption"] > div{ width:100%; }
section[data-testid="stSidebar"] label[data-testid="stRadioOption"] > div > div:first-child{ display:none; }
section[data-testid="stSidebar"] label[data-selected="true"]{
  background:linear-gradient(to right bottom,var(--primary),var(--secondary));
  box-shadow:0 6px 16px rgba(221,44,103,.28); }
section[data-testid="stSidebar"] label[data-selected="true"] *{ color:#fff !important; }
.side-card{ background:#fff; border:1px solid var(--border); border-radius:var(--radius);
  padding:12px 14px; font-size:.82rem; line-height:1.6; color:var(--muted-fg); }
.side-card b{ color:var(--fg); }
.side-tit{ font-size:.68rem; letter-spacing:.18em; text-transform:uppercase;
  color:var(--muted-fg); font-weight:700; margin:2px 0 6px; }

/* ---- metricas ---- */
div[data-testid="stMetric"]{ background:#fff; border:1px solid var(--border); border-radius:16px;
  padding:16px 18px; box-shadow:0 2px 10px rgba(221,44,103,.05); }
div[data-testid="stMetricLabel"] p{ color:var(--muted-fg); font-size:.78rem; font-weight:700;
  letter-spacing:.06em; text-transform:uppercase; }
div[data-testid="stMetricValue"]{ font-family:'Noto Serif',serif; color:var(--primary);
  font-size:clamp(1.15rem, 1.9vw, 1.65rem); white-space:normal; overflow:visible; text-overflow:clip; }
div[data-testid="stMetricValue"] > div{ overflow:visible; text-overflow:clip; }

/* ---- botoes ---- */
.stButton>button, .stFormSubmitButton>button, .stDownloadButton>button, .stLinkButton>a{
  background:linear-gradient(to right bottom,var(--primary),var(--secondary)); color:#fff !important;
  border:0; border-radius:16px; font-weight:600; padding:.55rem 1.3rem;
  box-shadow:0 8px 20px rgba(221,44,103,.28); transition:transform .12s, box-shadow .12s; }
.stButton>button:hover, .stFormSubmitButton>button:hover, .stDownloadButton>button:hover, .stLinkButton>a:hover{
  transform:translateY(-1px); box-shadow:0 10px 26px rgba(221,44,103,.36); color:#fff !important; }
.stButton>button[kind="secondary"]{ background:#fff; color:var(--accent-fg) !important;
  border:1px solid var(--border); box-shadow:none; }
.stButton>button[kind="secondary"]:hover{ background:var(--accent); }

/* ---- formularios ---- */
div[data-testid="stForm"]{ background:#fff; border:1px solid var(--border); border-radius:18px;
  padding:22px 24px; box-shadow:0 4px 18px rgba(221,44,103,.06); }
div[data-baseweb="input"], div[data-baseweb="select"]>div, div[data-baseweb="textarea"]{
  border-radius:var(--radius) !important; border-color:var(--border) !important; }
label p{ font-weight:600; font-size:.85rem; }

/* ---- abas / tabelas ---- */
.stTabs [data-baseweb="tab-list"]{ gap:6px; border-bottom:1px solid var(--border); }
.stTabs [data-baseweb="tab"]{ border-radius:12px 12px 0 0; padding:8px 18px; font-weight:600; }
.stTabs [aria-selected="true"]{ background:var(--accent); color:var(--accent-fg) !important; }
div[data-testid="stDataFrame"]{ border:1px solid var(--border); border-radius:14px; overflow:hidden; }

/* ---- cartoes / etiquetas ---- */
.card{ background:#fff; border:1px solid var(--border); border-radius:16px; padding:16px 18px;
  margin-bottom:10px; box-shadow:0 2px 10px rgba(221,44,103,.05); }
.card-top{ display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; }
.card b{ color:var(--fg); font-size:1rem; }
.card small{ color:var(--muted-fg); }
.tag{ display:inline-block; padding:3px 11px; border-radius:999px; font-size:.72rem; font-weight:700; }
.t-alto{ background:#E3F6EC; color:#18784C; } .t-medio{ background:#FEF3D7; color:#8A5A00; }
.t-baixo{ background:var(--accent); color:var(--accent-fg); }
.st-Pendente{ background:#FEF3D7; color:#8A5A00; } .st-Confirmado{ background:#E3F6EC; color:#18784C; }
.st-Concluido{ background:var(--muted); color:var(--muted-fg); } .st-Cancelado{ background:#FDE7E9; color:#9B1C24; }
.empty{ background:var(--card); border:1px dashed var(--border); border-radius:16px; padding:26px;
  text-align:center; color:var(--muted-fg); }
</style>
""", unsafe_allow_html=True)

dados = carregar()

PAGINAS = ["Painel", "Agendamentos", "Clientes", "Estoque", "Financeiro", "Localizacao", "Dados (JSON)"]

with st.sidebar:
    st.markdown("""<div class="hero" style="margin-bottom:14px">
        <div class="hero-logo">R</div>
        <div><div class="hero-tit" style="font-size:1.3rem">Revitalizar</div>
        <div class="hero-sub">Gestao de Salao</div></div></div>""", unsafe_allow_html=True)
    pagina = st.radio("Navegacao", PAGINAS, label_visibility="collapsed")
    st.divider()
    st.markdown('<div class="side-tit">Squad responsavel</div>', unsafe_allow_html=True)
    st.markdown("""<div class="side-card">
        <b>Squad G3</b><br>
        Cliente: <b>Revitalizar</b><br>
        Marketing: Edson, Safira, Matheus, Pyetro<br>
        Dev / Ciencia de Dados: Squad G3<br>
        Briefing: <b>v1.0</b> - 22/09/2026</div>""", unsafe_allow_html=True)
    st.caption("MVP academico - Vibe Coding com Streamlit")

st.markdown(f"""<div class="hero">
    <div class="hero-logo">R</div>
    <div><div class="hero-sub">Revitalizar - Squad G3</div>
    <div class="hero-tit">{'Painel de controle' if pagina == 'Painel' else pagina}</div></div>
</div>""", unsafe_allow_html=True)


def tag_status(s):
    return f'<span class="tag st-{s}">{s}</span>'


def tag_score(saida):
    cls = {"LEAD_QUALIFICADO_ALTO_VALOR": "t-alto", "LEAD_QUALIFICADO_MEDIO": "t-medio"}.get(
        saida["resultado_processado"], "t-baixo")
    return f'<span class="tag {cls}">score {saida["pontuacao_score"]}</span>'


def vazio(msg):
    st.markdown(f'<div class="empty">{msg}</div>', unsafe_allow_html=True)


# --------------------------------------------------------------------- PAINEL
if pagina == "Painel":
    ags = dados["agendamentos"]
    hoje = str(date.today())
    pendentes = [a for a in ags if a["status"] == "Pendente"]
    ent, sai, saldo = saldo_financeiro(dados)
    baixo = [p for p in dados["estoque"] if p["saldo"] <= p["minimo"]]
    sumidos = [c for c in resumo_clientes(dados)
               if c["dias_sem_voltar"] and c["dias_sem_voltar"] > DIAS_INATIVO]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Agendamentos", len(ags), f"{sum(1 for a in ags if a['data'] == hoje)} hoje")
    c2.metric("A confirmar", len(pendentes))
    c3.metric("Saldo em caixa", brl(saldo))
    c4.metric("Produtos em alerta", len(baixo), delta_color="inverse")

    st.divider()
    esq, dir_ = st.columns([3, 2])

    with esq:
        st.subheader("Proximos atendimentos")
        futuros = sorted([a for a in ags if a["data"] >= hoje and a["status"] in ("Pendente", "Confirmado")],
                         key=lambda a: (a["data"], a["hora"]))[:6]
        if not futuros:
            vazio("Nenhum atendimento na fila. Cadastre em <b>Agendamentos</b>.")
        for a in futuros:
            st.markdown(
                f"""<div class="card">
                <div class="card-top"><b>{a['cliente']}</b>
                <span>{tag_score(a['saida'])} {tag_status(a['status'])}</span></div>
                <div style="margin:6px 0 4px">{a['servico']} &middot;
                {datetime.fromisoformat(a['data']).strftime('%d/%m/%Y')} as {a['hora']} &middot; {a['profissional']}</div>
                <small>{brl(a['saida']['valor_final'])} &middot; {a['saida']['recomendacao_proximo_passo']}</small>
                </div>""", unsafe_allow_html=True)

    with dir_:
        st.subheader("Receita dos ultimos 14 dias")
        entradas = [m for m in dados["financeiro"] if m["tipo"] == "entrada"]
        serie = pd.Series(dtype=float)
        if entradas:
            df = pd.DataFrame(entradas)
            df["data"] = pd.to_datetime(df["data"])
            serie = df[df["data"] >= pd.Timestamp(date.today() - timedelta(days=14))].groupby("data")["valor"].sum()
        if serie.empty:
            vazio("Sem entradas no periodo.")
        else:
            st.bar_chart(serie, color="#DD2C67", height=210)

        st.subheader("Alertas de estoque")
        if baixo:
            for p in baixo:
                st.warning(f"**{p['produto']}**: {p['saldo']} un. (minimo {p['minimo']})")
        else:
            st.success("Estoque saudavel.")

        st.subheader("Clientes para reativar")
        if sumidos:
            for c in sumidos[:4]:
                st.markdown(f"""<div class="card"><b>{c['cliente']}</b><br>
                    <small>{c['dias_sem_voltar']} dias sem voltar &middot; {c['telefone']}<br>
                    Ja gastou {brl(c['total_gasto'])} em {c['visitas']} visita(s)</small></div>""",
                            unsafe_allow_html=True)
        else:
            vazio(f"Ninguem parado ha mais de {DIAS_INATIVO} dias.")

# --------------------------------------------------------------- AGENDAMENTOS
elif pagina == "Agendamentos":
    st.caption("RF01 - Agendamento de servicos e controle de atendimento (RNF02: confirmacao pelo atendente)")

    if "flash" in st.session_state:
        msg, avisos = st.session_state.pop("flash")
        st.success(msg)
        for av in avisos:
            st.warning(av)

    nova, lista = st.tabs(["Novo agendamento", f"Agenda ({len(dados['agendamentos'])})"])

    with nova:
        with st.form("form_ag", clear_on_submit=True):
            c1, c2 = st.columns(2)
            cliente = c1.text_input("Nome do cliente *", placeholder="Ex: Maria Silva")
            telefone = c2.text_input("WhatsApp *", placeholder="(11) 99999-0000")
            c3, c4 = st.columns(2)
            servico = c3.selectbox("Servico *", list(SERVICOS),
                                   format_func=lambda s: f"{s} - {brl(SERVICOS[s])}")
            profissional = c4.selectbox("Profissional *", PROFISSIONAIS)
            c5, c6 = st.columns(2)
            data_ag = c5.date_input("Data *", value=date.today(), min_value=date.today(), format="DD/MM/YYYY")
            hora = c6.time_input("Horario *", value=datetime.strptime("09:00", "%H:%M").time(), step=1800)
            c7, c8 = st.columns(2)
            orcamento = c7.number_input("Orcamento mensal do cliente (R$)", 0.0, 5000.0, 150.0, 50.0)
            recorrente = c8.checkbox("Cliente recorrente", value=False)
            obs = st.text_area("Observacoes", placeholder="Alergias, preferencias, origem do contato...")
            enviar = st.form_submit_button("Registrar agendamento")

        if enviar:
            erros = []
            if not cliente.strip():
                erros.append("Informe o nome do cliente.")
            if len("".join(filter(str.isdigit, telefone))) < 10:
                erros.append("WhatsApp invalido: informe DDD + numero.")
            if any(a["data"] == str(data_ag) and a["hora"] == hora.strftime("%H:%M")
                   and a["profissional"] == profissional and a["status"] != "Cancelado"
                   for a in dados["agendamentos"]):
                erros.append(f"{profissional} ja tem atendimento em {data_ag.strftime('%d/%m')} as "
                             f"{hora.strftime('%H:%M')}. Escolha outro horario ou profissional.")
            if erros:
                for e in erros:
                    st.error(e)
            else:
                saida = classificar(servico, data_ag, recorrente, orcamento)
                dados["agendamentos"].append({
                    "id": proximo_id(dados["agendamentos"], "AG"),
                    "cliente": cliente.strip(), "telefone": telefone.strip(),
                    "servico": servico, "profissional": profissional,
                    "data": str(data_ag), "hora": hora.strftime("%H:%M"),
                    "recorrente": recorrente, "orcamento_mensal": float(orcamento),
                    "observacoes": obs.strip(), "status": "Pendente",
                    "criado_em": datetime.now().isoformat(timespec="seconds"), "saida": saida,
                })
                salvar(dados)
                st.success(f"Agendamento registrado para {cliente.strip()}. "
                           "Aguardando confirmacao do atendente (RNF02).")
                m1, m2, m3 = st.columns(3)
                m1.metric("Score", saida["pontuacao_score"])
                m2.metric("Classificacao",
                          saida["resultado_processado"].removeprefix("LEAD_").replace("_", " ").title())
                m3.metric("Valor final", brl(saida["valor_final"]),
                          f"-{brl(saida['desconto_relampago'])} relampago" if saida["desconto_relampago"] else None)
                st.info(saida["recomendacao_proximo_passo"])
                falta = [f"{q}x {p}" for p, q in INSUMOS.get(servico, [])
                         if next((i["saldo"] for i in dados["estoque"] if i["produto"] == p), 0) < q]
                if falta:
                    st.warning("Estoque insuficiente para os insumos deste servico: " + ", ".join(falta))

    with lista:
        if not dados["agendamentos"]:
            vazio("Nenhum agendamento cadastrado ainda.")
        else:
            f1, f2, f3 = st.columns([1, 1, 2])
            filtro = f1.selectbox("Status", ["Todos"] + STATUS)
            prof = f2.selectbox("Profissional", ["Todos"] + PROFISSIONAIS)
            busca = f3.text_input("Buscar cliente", placeholder="nome...")
            mostrados = 0
            for a in sorted(dados["agendamentos"], key=lambda x: (x["data"], x["hora"]), reverse=True):
                if filtro != "Todos" and a["status"] != filtro:
                    continue
                if prof != "Todos" and a["profissional"] != prof:
                    continue
                if busca and busca.lower() not in a["cliente"].lower():
                    continue
                mostrados += 1
                with st.expander(f"{datetime.fromisoformat(a['data']).strftime('%d/%m')} {a['hora']} - "
                                 f"{a['cliente']} - {a['servico']} [{a['status']}]"):
                    c1, c2, c3 = st.columns(3)
                    c1.write(f"**Profissional:** {a['profissional']}")
                    c1.write(f"**WhatsApp:** {a['telefone']}")
                    c2.write(f"**Score:** {a['saida']['pontuacao_score']}/100")
                    c2.write(f"**Classificacao:** {a['saida']['resultado_processado']}")
                    c3.write(f"**Valor:** {brl(a['saida']['valor_final'])}")
                    c3.write(f"**Recorrente:** {'Sim' if a['recorrente'] else 'Nao'}")
                    if a["observacoes"]:
                        st.caption(f"Obs: {a['observacoes']}")
                    if a.get("insumos_baixados"):
                        st.caption("Baixa de estoque: " + " | ".join(a["insumos_baixados"]))
                    st.caption(a["saida"]["recomendacao_proximo_passo"])

                    b1, b2, b3 = st.columns(3)
                    if a["status"] == "Pendente" and b1.button("Confirmar", key=f"c{a['id']}"):
                        a["status"] = "Confirmado"
                        salvar(dados)
                        st.rerun()
                    if a["status"] in ("Pendente", "Confirmado") and b2.button(
                            "Concluir atendimento", key=f"f{a['id']}"):
                        baixados, avisos = concluir_atendimento(dados, a)
                        salvar(dados)
                        st.session_state["flash"] = (
                            f"Atendimento de {a['cliente']} concluido. Receita de "
                            f"{brl(a['saida']['valor_final'])} lancada e baixa no estoque: "
                            + (" | ".join(baixados) if baixados else "nenhum insumo vinculado."), avisos)
                        st.rerun()
                    if a["status"] != "Cancelado" and b3.button("Cancelar", key=f"x{a['id']}",
                                                                type="secondary"):
                        a["status"] = "Cancelado"
                        salvar(dados)
                        st.rerun()
            if mostrados == 0:
                vazio("Nenhum agendamento para esse filtro.")

# -------------------------------------------------------------------- CLIENTES
elif pagina == "Clientes":
    st.caption("Historico consolidado por cliente - base para a reativacao de quem sumiu")
    clientes = resumo_clientes(dados)
    if not clientes:
        vazio("Nenhum cliente ainda. Eles aparecem aqui assim que houver agendamentos.")
    else:
        ativos = [c for c in clientes if c["visitas"]]
        ticket = (sum(c["total_gasto"] for c in ativos) / sum(c["visitas"] for c in ativos)) if ativos else 0
        sumidos = [c for c in clientes if c["dias_sem_voltar"] and c["dias_sem_voltar"] > DIAS_INATIVO]
        c1, c2, c3 = st.columns(3)
        c1.metric("Clientes na base", len(clientes))
        c2.metric("Ticket medio", brl(ticket))
        c3.metric(f"Sem voltar ha +{DIAS_INATIVO} dias", len(sumidos), delta_color="inverse")

        st.dataframe(
            pd.DataFrame([{
                "Cliente": c["cliente"], "WhatsApp": c["telefone"], "Visitas": c["visitas"],
                "Total gasto (R$)": round(c["total_gasto"], 2),
                "Ultima visita": c["ultima_visita"] or "-",
                "Dias sem voltar": c["dias_sem_voltar"] if c["dias_sem_voltar"] is not None else "-",
                "Proximo agendamento": c["proximo"] or "-", "Servicos": c["servicos"],
            } for c in clientes]),
            use_container_width=True, hide_index=True,
        )
        if sumidos:
            st.subheader("Lista de reativacao")
            for c in sumidos:
                st.markdown(f"""<div class="card"><div class="card-top"><b>{c['cliente']}</b>
                    <span class="tag t-baixo">{c['dias_sem_voltar']} dias</span></div>
                    <small>{c['telefone']} &middot; {c['visitas']} visita(s) &middot;
                    {brl(c['total_gasto'])} &middot; servicos: {c['servicos']}</small></div>""",
                            unsafe_allow_html=True)

# --------------------------------------------------------------------- ESTOQUE
elif pagina == "Estoque":
    st.caption("RF02 - Entrada e saida de produtos, com baixa automatica ao concluir atendimentos")

    if "flash_estoque" in st.session_state:
        msg, aviso = st.session_state.pop("flash_estoque")
        st.success(msg)
        if aviso:
            st.warning(aviso)

    mov, novo = st.tabs(["Movimentar estoque", "Cadastrar produto"])
    with mov:
        with st.form("form_mov", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            produto = c1.selectbox("Produto", [p["produto"] for p in dados["estoque"]])
            tipo = c2.selectbox("Tipo", ["Entrada (compra)", "Saida (consumo/perda)"])
            qtd = c3.number_input("Quantidade", 1, 999, 1)
            motivo = st.text_input("Motivo / nota fiscal", placeholder="Ex: compra fornecedor X / produto vencido")
            lanc = st.checkbox("Lancar a compra no financeiro (RF03)", value=True)
            ok = st.form_submit_button("Registrar movimento")
        if ok:
            item = next(p for p in dados["estoque"] if p["produto"] == produto)
            entrada = tipo.startswith("Entrada")
            if not entrada and qtd > item["saldo"]:
                st.error(f"Saldo insuficiente: disponivel {item['saldo']} un. de {produto}.")
            else:
                item = mover_estoque(dados, produto, "entrada" if entrada else "saida", qtd,
                                     motivo.strip() or ("Compra" if entrada else "Consumo manual"))
                if entrada and lanc:
                    lancar_financeiro(dados, "saida", "Compra de produto", f"{qtd}x {produto}",
                                      qtd * item["custo"], date.today())
                salvar(dados)
                st.session_state["flash_estoque"] = (
                    f"Movimento registrado. Novo saldo de {produto}: {item['saldo']} un.",
                    f"{produto} atingiu o estoque minimo - reposicao recomendada."
                    if item["saldo"] <= item["minimo"] else None)
                st.rerun()

    with novo:
        with st.form("form_prod", clear_on_submit=True):
            c1, c2, c3, c4 = st.columns(4)
            nome = c1.text_input("Produto")
            saldo0 = c2.number_input("Saldo inicial", 0, 9999, 0)
            minimo = c3.number_input("Estoque minimo", 0, 999, 3)
            custo = c4.number_input("Custo unitario (R$)", 0.0, 9999.0, 0.0, 1.0)
            ok2 = st.form_submit_button("Cadastrar produto")
        if ok2:
            if not nome.strip():
                st.error("Informe o nome do produto.")
            elif any(p["produto"].lower() == nome.strip().lower() for p in dados["estoque"]):
                st.error("Produto ja cadastrado.")
            else:
                dados["estoque"].append({"produto": nome.strip(), "saldo": int(saldo0),
                                         "minimo": int(minimo), "custo": float(custo)})
                salvar(dados)
                st.session_state["flash_estoque"] = (f"Produto {nome.strip()} cadastrado.", None)
                st.rerun()

    df = pd.DataFrame(dados["estoque"])
    df["valor_total"] = df["saldo"] * df["custo"]
    df["situacao"] = df.apply(
        lambda r: "Repor agora" if r["saldo"] <= 0 else ("Abaixo do minimo" if r["saldo"] <= r["minimo"] else "OK"),
        axis=1)
    c1, c2, c3 = st.columns(3)
    c1.metric("Itens cadastrados", len(df))
    c2.metric("Valor imobilizado", brl(df["valor_total"].sum()))
    c3.metric("Abaixo do minimo", int((df["saldo"] <= df["minimo"]).sum()), delta_color="inverse")

    st.subheader("Posicao atual")
    st.dataframe(
        df.rename(columns={"produto": "Produto", "saldo": "Saldo", "minimo": "Minimo",
                           "custo": "Custo unit. (R$)", "valor_total": "Total (R$)", "situacao": "Situacao"}),
        use_container_width=True, hide_index=True)

    st.caption("Baixa automatica por servico -> " +
               " | ".join(f"{s}: {', '.join(f'{q}x {p}' for p, q in ins)}" for s, ins in INSUMOS.items()))

    if dados["movimentos_estoque"]:
        st.subheader("Historico de movimentos")
        st.dataframe(pd.DataFrame(dados["movimentos_estoque"][::-1]),
                     use_container_width=True, hide_index=True)

# ------------------------------------------------------------------ FINANCEIRO
elif pagina == "Financeiro":
    st.caption("RF03 - Gestao de entrada e saida de valores")
    ent, sai, saldo = saldo_financeiro(dados)
    c1, c2, c3 = st.columns(3)
    c1.metric("Entradas", brl(ent))
    c2.metric("Saidas", brl(sai))
    c3.metric("Saldo", brl(saldo))

    with st.form("form_fin", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        tipo = c1.selectbox("Tipo", ["entrada", "saida"])
        categoria = c2.selectbox("Categoria", ["Servico", "Produto", "Compra de produto",
                                               "Aluguel", "Salario", "Marketing", "Outros"])
        valor = c3.number_input("Valor (R$)", 0.0, 99999.0, 0.0, 10.0)
        c4, c5 = st.columns([2, 1])
        descricao = c4.text_input("Descricao", placeholder="Ex: venda de shampoo / conta de luz")
        data_mov = c5.date_input("Data", value=date.today(), format="DD/MM/YYYY")
        ok = st.form_submit_button("Lancar")
    if ok:
        if valor <= 0:
            st.error("Valor deve ser maior que zero.")
        elif not descricao.strip():
            st.error("Informe a descricao do lancamento.")
        else:
            lancar_financeiro(dados, tipo, categoria, descricao.strip(), valor, data_mov)
            salvar(dados)
            st.rerun()

    if dados["financeiro"]:
        df = pd.DataFrame(dados["financeiro"][::-1])
        st.subheader("Lancamentos")
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.subheader("Resultado por categoria")
        st.bar_chart(df.pivot_table(index="categoria", columns="tipo", values="valor", aggfunc="sum").fillna(0),
                     color=["#29A36A", "#DD2C67"])
    else:
        vazio("Nenhum lancamento. Conclua um atendimento para gerar receita automaticamente.")

# ----------------------------------------------------------------- LOCALIZACAO
elif pagina == "Localizacao":
    st.caption("RF04 - Localizacao e divulgacao")
    c1, c2 = st.columns([2, 3])
    with c1:
        st.markdown(f"""<div class="card">
        <b>Revitalizar - Salao de Beleza</b><br><br>
        {ENDERECO['logradouro']}<br>{ENDERECO['cidade']}<br>CEP {ENDERECO['cep']}<br><br>
        Telefone / WhatsApp: <b>{ENDERECO['telefone']}</b>
        </div>""", unsafe_allow_html=True)
        st.markdown('<div class="side-tit">Horarios de atendimento</div>', unsafe_allow_html=True)
        for dia, h in ENDERECO["horarios"].items():
            st.write(f"- {dia}: {h}")
        st.success(f"Promocao relampago: {int(DESCONTO_RELAMPAGO * 100)}% de desconto em agendamentos "
                   "de **segunda e terca**.")
        st.link_button("Abrir no Google Maps",
                       f"https://www.google.com/maps/search/?api=1&query={ENDERECO['lat']},{ENDERECO['lon']}")
    with c2:
        st.map(pd.DataFrame([{"lat": ENDERECO["lat"], "lon": ENDERECO["lon"]}]), zoom=14)

# ------------------------------------------------------------------ JSON/RNF01
else:
    st.caption("RNF01 - Toda a comunicacao do sistema em estrutura JSON")
    pacote = {
        "cliente_marketing": "Revitalizar", "versao_briefing": "1.0", "squad": "G3",
        "gerado_em": datetime.now().isoformat(timespec="seconds"),
        "resumo": {
            "total_agendamentos": len(dados["agendamentos"]),
            "pendentes_confirmacao": sum(1 for a in dados["agendamentos"] if a["status"] == "Pendente"),
            "saldo_caixa": round(saldo_financeiro(dados)[2], 2),
            "produtos_em_alerta": [p["produto"] for p in dados["estoque"] if p["saldo"] <= p["minimo"]],
        },
        **dados,
    }
    c1, c2 = st.columns([1, 3])
    c1.download_button("Baixar JSON completo", json.dumps(pacote, ensure_ascii=False, indent=2),
                       "revitalizar_dados.json", "application/json")
    c2.caption(f"Banco local: {DB.name} - {DB.stat().st_size if DB.exists() else 0} bytes, "
               "gravado de forma atomica a cada operacao.")
    st.json(pacote, expanded=False)

    if dados["agendamentos"]:
        st.subheader("Exemplo de registro no schema do briefing")
        a = dados["agendamentos"][-1]
        st.code(json.dumps({
            "cliente_marketing": "Revitalizar", "versao_briefing": "1.0",
            "dados_entrada_usuario": {
                "campo_1": a["cliente"],
                "campo_2": f"Orcamento_Mensal_{a['orcamento_mensal']:.2f}R$",
                "campo_3": a["data"],
            },
            "dados_saida_sistema": {
                "resultado_processado": a["saida"]["resultado_processado"],
                "pontuacao_score": a["saida"]["pontuacao_score"],
                "recomendacao_proximo_passo": a["saida"]["recomendacao_proximo_passo"],
            },
        }, ensure_ascii=False, indent=2), language="json")

    with st.expander("schema_dados.json"):
        st.code(SCHEMA.read_text(encoding="utf-8") if SCHEMA.exists() else "{}", language="json")
