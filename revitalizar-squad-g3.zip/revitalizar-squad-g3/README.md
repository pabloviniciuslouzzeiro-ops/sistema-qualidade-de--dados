# Sistema de Gestao para Salao - Revitalizar

MVP funcional construido com **Vibe Coding** (Python + Streamlit) a partir do briefing
de descoberta de produto da **Squad G3**.

- **Cliente:** Revitalizar (salao de beleza)
- **Marketing / Stakeholders:** Edson, Safira, Matheus, Pyetro
- **Dev / Ciencia de Dados:** Squad G3
- **Briefing:** v1.0 - alinhamento em 22/09/2026
- **UX/UI:** tokens de design da referencia `divasbyregiane.vercel.app`

---

# 1. Ferramentas necessarias no PC

Checklist do que precisa estar em um computador novo antes de rodar o projeto.
Na pratica **so o Python precisa ser baixado** - navegador e terminal ja vem no sistema,
o pip vem junto com o Python, e Git e VS Code sao opcionais.

| # | Ferramenta | Para que serve | Obrigatorio? | Onde baixar |
|---|-----------|----------------|--------------|-------------|
| 1 | **Python 3.10+** | Linguagem em que o sistema foi escrito. Roda o servidor da aplicacao | **Sim** | https://www.python.org/downloads/ |
| 2 | **pip** | Instalador de bibliotecas (Streamlit e pandas) | **Sim** - ja vem junto com o Python | (nao precisa baixar) |
| 3 | **Navegador web** (Chrome, Edge, Firefox) | Abrir a tela do sistema em `localhost:8501` | **Sim** - ja vem no Windows/macOS | https://www.google.com/chrome/ |
| 4 | **Terminal** (PowerShell, Terminal, Bash) | Digitar os comandos | **Sim** - ja vem no sistema | (nao precisa baixar) |
| 5 | **Git** | Clonar e versionar o repositorio da squad | Opcional - so se for usar GitHub | https://git-scm.com/downloads |
| 6 | **VS Code** | Editar o codigo e ver os arquivos | Opcional | https://code.visualstudio.com/download |

Bibliotecas Python instaladas pelo `requirements.txt` no Passo 5 (nao baixe manualmente):

| Biblioteca | Para que serve |
|-----------|----------------|
| `streamlit` | Cria a interface web do sistema |
| `pandas` | Tabelas, graficos e calculos |

## Como instalar cada uma

### Python 3.10 ou superior (obrigatorio)

1. Acesse **https://www.python.org/downloads/** - o site detecta seu sistema e mostra o
   botao amarelo *Download Python 3.x.x*.
2. Execute o arquivo baixado.
3. **Windows:** na primeira tela marque **"Add python.exe to PATH"** e so depois clique em
   *Install Now*. Essa caixa e a causa numero 1 de erro depois.
   **macOS:** avance o instalador normalmente (*Continuar / Instalar*).
   **Linux (Ubuntu/Debian):** em vez do site, rode no terminal
   `sudo apt update && sudo apt install python3 python3-pip python3-venv`.
4. Feche e abra o terminal de novo e confira:

```bash
python --version
```

Deve responder `Python 3.10` ou maior. No macOS/Linux, se `python` nao existir, use
`python3` em todos os comandos deste guia.

### pip (ja vem com o Python)

Nao precisa instalar. Confira com:

```bash
pip --version
```

Se der erro no Windows, use `python -m pip` no lugar de `pip`.

### Navegador (ja vem no sistema)

Qualquer navegador moderno serve. Se quiser instalar o Chrome:
**https://www.google.com/chrome/**

### Git (opcional - so para o GitHub)

1. Baixe em **https://git-scm.com/downloads** e execute o instalador aceitando as opcoes
   padrao (no Windows isso tambem instala o *Git Bash*).
2. Confira: `git --version`

### VS Code (opcional - para editar o codigo)

1. Baixe em **https://code.visualstudio.com/download** e instale.
2. Abra o VS Code, va em *File -> Open Folder* e escolha a pasta do projeto.
3. Recomendado: instale a extensao **Python** da Microsoft (icone de blocos na lateral
   esquerda -> pesquise por `Python` -> *Install*).
4. O terminal integrado abre com **`Ctrl + '`** - da para rodar os comandos deste guia
   por ali.

---

# 2. Como executar na sua maquina (passo a passo)

> Tempo estimado: 5 minutos. Funciona em Windows, macOS e Linux.
> Voce so precisa do Python instalado - nao precisa de banco de dados, servidor,
> conta em nuvem nem internet (so na primeira instalacao).

## Passo 1 - Conferir se o Python esta instalado

Instale o Python seguindo a secao 1 deste README, depois abra o terminal e rode:

```bash
python --version
```

Deve aparecer algo como `Python 3.12.4`. Se aparecer erro, o Python nao foi instalado
ou nao foi adicionado ao PATH - volte a secao 1.

**Como abrir o terminal:**

| Sistema | Como abrir |
|---------|-----------|
| Windows | Tecla `Windows` -> digite `powershell` -> Enter |
| macOS | `Cmd + Espaco` -> digite `terminal` -> Enter |
| Linux | `Ctrl + Alt + T` |

## Passo 2 - Baixar o projeto

**Opcao A - voce recebeu o arquivo .zip:** clique com o botao direito no arquivo e
escolha *Extrair tudo* (Windows) ou *Abrir com o Gerenciador de Arquivamento* (Linux/macOS).
Guarde a pasta em um lugar facil, por exemplo `Documentos`.

**Opcao B - clonando do GitHub da squad:**

```bash
git clone https://github.com/SUA-ORG/SEU-REPOSITORIO.git
```

## Passo 3 - Entrar na pasta do projeto pelo terminal

Use o comando `cd` seguido do caminho da pasta. Exemplos:

```bash
cd "C:\Users\SeuUsuario\Documents\revitalizar"
```

```bash
cd ~/Documents/revitalizar
```

Dica: no Windows voce pode digitar `cd ` (com espaco) e **arrastar a pasta** para dentro
da janela do terminal - o caminho e preenchido sozinho.

Confirme que voce esta no lugar certo listando os arquivos:

```bash
dir
```

(no macOS/Linux use `ls`). Voce deve ver `app.py`, `README.md` e `schema_dados.json`.

## Passo 4 - Criar o ambiente virtual (recomendado)

O ambiente virtual isola as bibliotecas deste projeto das outras do seu computador.

```bash
python -m venv .venv
```

Agora **ative** o ambiente:

| Sistema / terminal | Comando de ativacao |
|--------------------|---------------------|
| Windows (PowerShell) | `.venv\Scripts\Activate.ps1` |
| Windows (Prompt de comando) | `.venv\Scripts\activate.bat` |
| macOS / Linux | `source .venv/bin/activate` |

Deu certo quando aparece `(.venv)` no inicio da linha do terminal.

> **Erro no PowerShell** dizendo que a execucao de scripts esta desabilitada? Rode uma
> unica vez: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` e responda `S`.
> Se preferir, pule o ambiente virtual e va direto para o Passo 5 - tambem funciona.

## Passo 5 - Instalar as dependencias

```bash
pip install -r requirements.txt
```

Isso instala o **Streamlit** (a interface web) e o **pandas** (tabelas e graficos).
Demora cerca de 1 minuto na primeira vez.

## Passo 6 - Rodar a aplicacao

```bash
streamlit run app.py
```

O navegador abre sozinho em **http://localhost:8501**.
Se nao abrir, copie esse endereco e cole no navegador manualmente.

O terminal precisa **continuar aberto** enquanto voce usa o sistema - ele e o servidor.

## Passo 7 - Usar o sistema

1. **Painel** - visao geral do dia: agendamentos, caixa, alertas de estoque e clientes
   para reativar.
2. **Agendamentos -> Novo agendamento** - preencha nome, WhatsApp, servico, profissional,
   data e horario e clique em *Registrar agendamento*. O sistema calcula o score do lead
   e aplica o desconto relampago se for segunda ou terca.
3. **Agendamentos -> Agenda** - abra um agendamento e use *Confirmar* (o atendente confirma,
   conforme o RNF02), *Concluir atendimento* ou *Cancelar*.
   Ao concluir, a receita entra no financeiro **e** os insumos saem do estoque automaticamente.
4. **Estoque** - registre compras e perdas, cadastre produtos e acompanhe o historico.
5. **Financeiro** - lance despesas e receitas avulsas e veja o resultado por categoria.
6. **Clientes** - historico por cliente e lista de quem nao volta ha mais de 30 dias.
7. **Dados (JSON)** - baixe toda a base em JSON (RNF01).

## Passo 8 - Parar a aplicacao

No terminal, pressione **`Ctrl + C`**. Para sair do ambiente virtual, digite `deactivate`.

Para rodar de novo depois, basta repetir os passos 3, 4 (ativacao) e 6.

## Se algo der errado

| Mensagem no terminal | O que fazer |
|----------------------|-------------|
| `'python' nao e reconhecido...` | O Python nao foi adicionado ao PATH. Reinstale marcando *Add python.exe to PATH*, ou use `py` no lugar de `python` |
| `'streamlit' nao e reconhecido...` | O `pip install` nao rodou ou o ambiente virtual nao esta ativo. Refaca os passos 4 e 5, ou use `python -m streamlit run app.py` |
| `ModuleNotFoundError: No module named 'pandas'` | Falta instalar as dependencias: `pip install -r requirements.txt` |
| `Port 8501 is already in use` | Ja existe uma aplicacao rodando nessa porta. Feche a outra janela do terminal ou rode `streamlit run app.py --server.port 8502` |
| A pagina abre em branco | Aguarde alguns segundos e atualize com `F5`; confira se o terminal continua aberto |
| Quero comecar do zero, sem os dados de exemplo | Apague o arquivo `dados.json` e rode de novo - ele e recriado vazio |

## Rodar os testes (opcional)

```bash
python test_app.py
```

Devem aparecer 5 linhas comecando com `ok`.

---

# 3. O que o sistema faz

## Problema de negocio

Gestao de atendimento desorganizada e ausencia de clientes, principalmente nas
segundas e tercas (dias de baixo movimento). Falta controle de estoque e de caixa.

## Requisitos atendidos

| ID | Requisito | Onde esta no sistema |
|----|-----------|----------------------|
| RF01 | Agendamento de servicos e controle de atendimento | **Agendamentos**: cadastro, validacao, conflito de horario, confirmacao, conclusao, cancelamento, score do lead |
| RF02 | Gestao de entrada e saida de produtos | **Estoque**: saldo, minimo, situacao, entrada/saida manual, **baixa automatica ao concluir atendimento**, historico com a origem do movimento |
| RF03 | Gestao de entrada e saida de valores | **Financeiro**: entradas/saidas, saldo, grafico por categoria, lancamentos automaticos vindos do atendimento e da compra de produto |
| RF04 | Apresenta localizacao | **Localizacao**: mapa, endereco, horarios, link do Google Maps |
| RNF01 | Comunicacao via estrutura JSON | **Dados (JSON)** + `schema_dados.json` + download do pacote completo |
| RNF02 | Agendamento confirmado pelo atendente | Todo agendamento nasce **Pendente**; so o atendente muda para **Confirmado** |
| RNF03 | Responsivo para celular | Layout em colunas do Streamlit, testado em 375px |

Extra: pagina **Clientes** com historico consolidado (visitas, total gasto, ticket medio,
dias sem voltar) e **lista de reativacao** de quem nao volta ha mais de 30 dias - ataque
direto a dor de "ausencia de clientes".

## Automacoes entre modulos

| Acao | Efeito automatico |
|------|-------------------|
| Concluir atendimento | Lanca a receita no financeiro **e** da baixa nos insumos do servico no estoque, com aviso de estoque minimo ou saldo negativo |
| Registrar entrada de produto | Lanca a despesa da compra no financeiro (opcional, marcado por padrao) |
| Agendar servico sem insumo em estoque | Avisa na hora quais insumos vao faltar |

Consumo por servico (`INSUMOS` em `app.py`):

| Servico | Insumos baixados |
|---------|------------------|
| Progressiva sem formol | 1x Progressiva sem formol (1L), 1x Shampoo profissional (1L) |
| Escova / Hidratacao | 1x Shampoo profissional (1L) |
| Manicure / Pedicure | 1x Esmalte (unidade), 1x Algodao / acetona (kit) |
| Higienizacao de pes e unhas | 1x Algodao / acetona (kit) |
| Terapia por ventosa | 1x Ventosa de silicone (kit) |

## Regra de negocio (score do agendamento)

```
score = 40 (base)
      + ate 25  -> ticket do servico (valor / 180 * 25)
      + 15      -> cliente recorrente
      + ate 15  -> potencial mensal (orcamento / 500 * 15)
      + 5       -> agendamento em segunda ou terca (ocupa dia ocioso)
```

| Faixa | Classificacao | Proximo passo |
|-------|---------------|---------------|
| >= 80 | LEAD_QUALIFICADO_ALTO_VALOR | Confirmar por WhatsApp hoje e oferecer pacote fidelidade |
| 60-79 | LEAD_QUALIFICADO_MEDIO | Confirmar em ate 24h e lembrar 1 dia antes |
| < 60 | LEAD_BAIXA_PRIORIDADE | Lembrete automatico + promocao relampago |

**Promocao relampago:** 15% de desconto automatico em agendamentos de segunda e terca.

## Banco de dados local (JSON)

Tudo vive em `dados.json`, sem servidor e sem dependencia extra:

- **Escrita atomica**: grava em `dados.tmp` e usa `os.replace`, entao uma falha no meio
  da gravacao nao corrompe a base.
- **Leitura a cada interacao**: nada fica preso em cache de sessao, duas abas abertas
  enxergam o mesmo estado.
- **Migracao automatica**: chaves novas sao criadas ao abrir uma base antiga, sem quebrar.
- **IDs sequenciais** `AG0001` / `FIN0001`, com `origem` ligando o lancamento financeiro
  e o movimento de estoque ao agendamento que os gerou.

Estrutura: `_meta`, `agendamentos[]`, `estoque[]`, `movimentos_estoque[]`, `financeiro[]`.
Os dados de cliente sao **derivados** dos agendamentos, nao duplicados.

---

# 4. Arquivos do projeto

| Arquivo | Conteudo |
|---------|----------|
| `app.py` | Aplicacao Streamlit completa (UI + regras + banco JSON) |
| `requirements.txt` | Dependencias do projeto |
| `schema_dados.json` | Contrato de dados acordado com o Marketing |
| `dados.json` | Banco local com dados de exemplo (recriado se apagado) |
| `test_app.py` | Checagens das regras de negocio |
| `.streamlit/config.toml` | Tema claro do Streamlit |
| `README.md` | Este documento |

# 5. Versionamento no GitHub

```bash
git checkout -b feature-mvp-streamlit
git add app.py README.md schema_dados.json requirements.txt test_app.py .streamlit
git commit -m "feat: MVP do sistema de gestao do salao Revitalizar (Squad G3)"
git push origin feature-mvp-streamlit
```

# 6. Criterios de aceite (DoD)

- [x] Formulario funcionando sem erros, com validacao de campos vazios, invalidos e conflito de agenda
- [x] Classificacao e calculo corretos conforme a regra alinhada com o Marketing
- [x] Estoque atualizado automaticamente apos cada retirada/atendimento
- [ ] Dados versionados no repositorio da squad no GitHub
