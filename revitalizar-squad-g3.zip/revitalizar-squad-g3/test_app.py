"""Checks minimos das regras de negocio: python test_app.py"""
import json
from datetime import date

from app import (DESCONTO_RELAMPAGO, INSUMOS, SERVICOS, VAZIO, classificar,
                 concluir_atendimento, mover_estoque, resumo_clientes, saldo_financeiro)

TERCA = date(2026, 9, 29)   # dia relampago
QUARTA = date(2026, 9, 30)  # dia normal


def base():
    return json.loads(json.dumps(VAZIO))


def agendamento(servico="Manicure", cliente="Ana", data_ag=QUARTA, status="Confirmado"):
    return {"id": "AG0001", "cliente": cliente, "telefone": "(11) 90000-0000", "servico": servico,
            "profissional": "Safira", "data": str(data_ag), "hora": "09:00", "recorrente": False,
            "orcamento_mensal": 100.0, "observacoes": "", "status": status,
            "saida": classificar(servico, data_ag, False, 100.0)}


def test_score():
    alto = classificar("Progressiva sem formol", QUARTA, recorrente=True, orcamento_mensal=500)
    assert alto["pontuacao_score"] == 95, alto
    assert alto["resultado_processado"] == "LEAD_QUALIFICADO_ALTO_VALOR"
    assert alto["desconto_relampago"] == 0.0
    assert alto["valor_final"] == SERVICOS["Progressiva sem formol"]

    baixo = classificar("Manicure", QUARTA, recorrente=False, orcamento_mensal=0)
    assert baixo["pontuacao_score"] < 60 and baixo["resultado_processado"] == "LEAD_BAIXA_PRIORIDADE"

    relampago = classificar("Manicure", TERCA, recorrente=False, orcamento_mensal=0)
    assert relampago["pontuacao_score"] == baixo["pontuacao_score"] + 5
    assert relampago["valor_final"] == round(SERVICOS["Manicure"] * (1 - DESCONTO_RELAMPAGO), 2)

    for s in SERVICOS:
        for d in (TERCA, QUARTA):
            assert 0 <= classificar(s, d, True, 99999)["pontuacao_score"] <= 100


def test_baixa_de_estoque_ao_concluir():
    dados = base()
    ag = agendamento("Manicure")
    dados["agendamentos"].append(ag)
    antes = {p["produto"]: p["saldo"] for p in dados["estoque"]}

    baixados, avisos = concluir_atendimento(dados, ag)

    assert ag["status"] == "Concluido"
    for produto, qtd in INSUMOS["Manicure"]:
        item = next(p for p in dados["estoque"] if p["produto"] == produto)
        assert item["saldo"] == antes[produto] - qtd, (produto, item)
    assert len(baixados) == len(INSUMOS["Manicure"])
    assert len(dados["movimentos_estoque"]) == len(INSUMOS["Manicure"])
    assert all(m["origem"] == ag["id"] for m in dados["movimentos_estoque"])
    # receita lancada uma unica vez, no valor final do agendamento
    assert saldo_financeiro(dados)[0] == ag["saida"]["valor_final"]
    assert avisos == []


def test_aviso_quando_estoque_acaba():
    dados = base()
    ventosa = next(p for p in dados["estoque"] if p["produto"] == "Ventosa de silicone (kit)")
    ventosa["saldo"] = 1  # abaixo do minimo depois da baixa
    ag = agendamento("Terapia por ventosa")
    _, avisos = concluir_atendimento(dados, ag)
    assert ventosa["saldo"] == 0
    assert avisos and "estoque minimo" in avisos[0]

    # segunda baixa sem saldo -> negativo e aviso de furo
    ag2 = agendamento("Terapia por ventosa")
    ag2["id"] = "AG0002"
    _, avisos2 = concluir_atendimento(dados, ag2)
    assert ventosa["saldo"] == -1
    assert avisos2 and "negativo" in avisos2[0]


def test_entrada_repoe_saldo():
    dados = base()
    item = mover_estoque(dados, "Esmalte (unidade)", "entrada", 10, "compra")
    assert item["saldo"] == 34
    assert dados["movimentos_estoque"][-1]["saldo_apos"] == 34


def test_resumo_clientes():
    dados = base()
    ag = agendamento("Manicure", cliente="Ana", data_ag=date(2026, 1, 10))
    dados["agendamentos"].append(ag)
    concluir_atendimento(dados, ag)
    c = resumo_clientes(dados)[0]
    assert c["cliente"] == "Ana" and c["visitas"] == 1
    assert c["total_gasto"] == ag["saida"]["valor_final"]
    assert c["dias_sem_voltar"] == (date.today() - date(2026, 1, 10)).days


if __name__ == "__main__":
    for nome, fn in list(globals().items()):
        if nome.startswith("test_"):
            fn()
            print(f"ok  {nome}")
